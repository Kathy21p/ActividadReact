# Proyecto React: Mis Películas

Aplicación completa realizada con React, JSX, componentes funcionales y Hooks. Permite crear, buscar, editar y eliminar películas. Los datos quedan guardados en el navegador mediante `localStorage`.

## Funcionalidades

- Listado inicial de películas.
- Alta mediante formulario controlado.
- Búsqueda instantánea por título o descripción.
- Edición dentro de cada tarjeta.
- Eliminación de películas.
- Persistencia automática con `localStorage`.
- Diseño adaptable a computadora, tablet y celular.
- Componentes separados y código comentado mediante nombres descriptivos.

## Cómo ejecutarlo

1. Abrí esta carpeta en Visual Studio Code.
2. Abrí una terminal dentro de la carpeta.
3. Instalá las dependencias:

   ```bash
   npm install
   ```

4. Iniciá el proyecto:

   ```bash
   npm run dev
   ```

5. Abrí la dirección que aparece en la terminal, normalmente `http://localhost:5173`.

## Estructura importante

- `src/App.jsx`: estado principal y operaciones CRUD.
- `src/components/`: componentes visuales de la aplicación.
- `src/helpers/almacenamiento.js`: lectura y escritura en `localStorage`.
- `src/data/peliculasIniciales.js`: datos que se muestran la primera vez.
- `src/index.css`: diseño completo y responsive.

## Crear la versión para entregar

```bash
npm run build
```

El resultado se genera en la carpeta `dist`.
