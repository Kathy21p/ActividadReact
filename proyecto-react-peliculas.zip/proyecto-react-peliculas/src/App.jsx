import { useEffect, useMemo, useState } from "react";
import Header from "./components/Header.jsx";
import Buscador from "./components/Buscador.jsx";
import Crear from "./components/Crear.jsx";
import Listado from "./components/Listado.jsx";
import Footer from "./components/Footer.jsx";
import { peliculasIniciales } from "./data/peliculasIniciales.js";
import { guardarPeliculas, obtenerPeliculas } from "./helpers/almacenamiento.js";

export default function App() {
  const [peliculas, setPeliculas] = useState(() => {
    const guardadas = obtenerPeliculas();
    return guardadas.length ? guardadas : peliculasIniciales;
  });
  const [termino, setTermino] = useState("");
  const [idEditando, setIdEditando] = useState(null);

  useEffect(() => {
    guardarPeliculas(peliculas);
  }, [peliculas]);

  const peliculasFiltradas = useMemo(() => {
    const consulta = termino.trim().toLocaleLowerCase("es");
    if (!consulta) return peliculas;
    return peliculas.filter((pelicula) =>
      `${pelicula.titulo} ${pelicula.descripcion}`.toLocaleLowerCase("es").includes(consulta),
    );
  }, [peliculas, termino]);

  const crearPelicula = (datos) => {
    const nueva = { id: crypto.randomUUID(), ...datos };
    setPeliculas((actuales) => [nueva, ...actuales]);
  };

  const guardarEdicion = (actualizada) => {
    setPeliculas((actuales) => actuales.map((pelicula) =>
      pelicula.id === actualizada.id ? actualizada : pelicula,
    ));
    setIdEditando(null);
  };

  const eliminarPelicula = (id) => {
    setPeliculas((actuales) => actuales.filter((pelicula) => pelicula.id !== id));
    if (idEditando === id) setIdEditando(null);
  };

  return (
    <div className="app" id="inicio">
      <Header />
      <main>
        <section className="hero">
          <div>
            <span className="hero__sobrelinea">Tu colección personal</span>
            <h2>Historias que vale la pena recordar.</h2>
            <p>Organizá tus películas favoritas en una aplicación hecha completamente con React.</p>
          </div>
          <div className="hero__numero">
            <strong>{peliculas.length}</strong>
            <span>{peliculas.length === 1 ? "película guardada" : "películas guardadas"}</span>
          </div>
        </section>

        <div className="contenido">
          <Listado
            peliculas={peliculasFiltradas}
            idEditando={idEditando}
            onEditar={setIdEditando}
            onGuardar={guardarEdicion}
            onCancelar={() => setIdEditando(null)}
            onEliminar={eliminarPelicula}
          />
          <aside>
            <Buscador termino={termino} onBuscar={setTermino} cantidad={peliculasFiltradas.length} />
            <Crear onCrear={crearPelicula} />
          </aside>
        </div>
      </main>
      <Footer />
    </div>
  );
}
