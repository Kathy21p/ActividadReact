export const peliculasIniciales = [
  {
    id: "demo-1",
    titulo: "El Señor de los Anillos",
    descripcion: "Una aventura épica para destruir el Anillo Único y proteger la Tierra Media.",
  },
  {
    id: "demo-2",
    titulo: "Volver al Futuro",
    descripcion: "Marty McFly viaja accidentalmente al pasado en un DeLorean convertido en máquina del tiempo.",
  },
  {
    id: "demo-3",
    titulo: "Interestelar",
    descripcion: "Un grupo de exploradores cruza un agujero de gusano para buscar un nuevo hogar para la humanidad.",
  },
];
