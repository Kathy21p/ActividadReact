const CLAVE = "peliculas-react";

export function obtenerPeliculas() {
  try {
    return JSON.parse(localStorage.getItem(CLAVE)) ?? [];
  } catch {
    return [];
  }
}

export function guardarPeliculas(peliculas) {
  localStorage.setItem(CLAVE, JSON.stringify(peliculas));
}
