import Editar from "./Editar.jsx";

export default function Pelicula({ pelicula, editando, onEditar, onGuardar, onCancelar, onEliminar }) {
  return (
    <article className="pelicula">
      <div className="pelicula__poster" aria-hidden="true">
        <span>{pelicula.titulo.charAt(0).toUpperCase()}</span>
      </div>
      <div className="pelicula__contenido">
        {editando ? (
          <Editar pelicula={pelicula} onGuardar={onGuardar} onCancelar={onCancelar} />
        ) : (
          <>
            <div>
              <span className="etiqueta">Película</span>
              <h3>{pelicula.titulo}</h3>
              <p>{pelicula.descripcion}</p>
            </div>
            <div className="acciones">
              <button className="boton boton--secundario" onClick={onEditar}>Editar</button>
              <button className="boton boton--peligro" onClick={onEliminar}>Eliminar</button>
            </div>
          </>
        )}
      </div>
    </article>
  );
}
