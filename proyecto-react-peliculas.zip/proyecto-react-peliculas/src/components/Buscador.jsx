export default function Buscador({ termino, onBuscar, cantidad }) {
  return (
    <section className="panel" aria-labelledby="titulo-buscador">
      <div className="panel__cabecera">
        <h2 id="titulo-buscador">Buscar</h2>
        <span className="contador">{cantidad}</span>
      </div>
      <label className="campo">
        <span className="sr-only">Título de la película</span>
        <input
          type="search"
          value={termino}
          onChange={(evento) => onBuscar(evento.target.value)}
          placeholder="Escribí un título..."
        />
      </label>
      {termino && (
        <button className="boton boton--fantasma boton--ancho" onClick={() => onBuscar("")}>
          Limpiar búsqueda
        </button>
      )}
    </section>
  );
}
