export default function Header() {
  return (
    <header className="header">
      <div className="marca" aria-label="Mis Películas">
        <span className="marca__icono">▶</span>
        <h1>Mis Películas</h1>
      </div>
      <nav aria-label="Navegación principal">
        <a href="#inicio">Inicio</a>
        <a href="#listado">Películas</a>
        <a href="#crear">Agregar</a>
      </nav>
    </header>
  );
}
