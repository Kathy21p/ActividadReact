export default function Footer() {
  return (
    <footer>
      Proyecto práctico creado con React, componentes, JSX, Hooks y localStorage.
    </footer>
  );
}
