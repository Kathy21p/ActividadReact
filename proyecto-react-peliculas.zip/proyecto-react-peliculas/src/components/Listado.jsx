import Pelicula from "./Pelicula.jsx";

export default function Listado({ peliculas, idEditando, onEditar, onGuardar, onCancelar, onEliminar }) {
  if (!peliculas.length) {
    return (
      <div className="vacio">
        <span>🎬</span>
        <h2>No encontramos películas</h2>
        <p>Probá con otra búsqueda o agregá una nueva desde el formulario.</p>
      </div>
    );
  }

  return (
    <section id="listado" className="listado" aria-label="Listado de películas">
      {peliculas.map((pelicula) => (
        <Pelicula
          key={pelicula.id}
          pelicula={pelicula}
          editando={idEditando === pelicula.id}
          onEditar={() => onEditar(pelicula.id)}
          onGuardar={onGuardar}
          onCancelar={onCancelar}
          onEliminar={() => onEliminar(pelicula.id)}
        />
      ))}
    </section>
  );
}
