import { useState } from "react";

const VACIO = { titulo: "", descripcion: "" };

export default function Crear({ onCrear }) {
  const [formulario, setFormulario] = useState(VACIO);
  const [error, setError] = useState("");

  const actualizar = ({ target }) => {
    setFormulario((actual) => ({ ...actual, [target.name]: target.value }));
    setError("");
  };

  const enviar = (evento) => {
    evento.preventDefault();
    const titulo = formulario.titulo.trim();
    const descripcion = formulario.descripcion.trim();

    if (!titulo || !descripcion) {
      setError("Completá el título y la descripción.");
      return;
    }

    onCrear({ titulo, descripcion });
    setFormulario(VACIO);
  };

  return (
    <section id="crear" className="panel" aria-labelledby="titulo-crear">
      <h2 id="titulo-crear">Agregar película</h2>
      <form onSubmit={enviar} noValidate>
        <label className="campo">
          <span>Título</span>
          <input name="titulo" value={formulario.titulo} onChange={actualizar} placeholder="Ej.: Matrix" />
        </label>
        <label className="campo">
          <span>Descripción</span>
          <textarea
            name="descripcion"
            value={formulario.descripcion}
            onChange={actualizar}
            placeholder="Escribí una breve sinopsis..."
            rows="5"
          />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="boton boton--primario boton--ancho" type="submit">Guardar película</button>
      </form>
    </section>
  );
}
