import { useState } from "react";

export default function Editar({ pelicula, onGuardar, onCancelar }) {
  const [datos, setDatos] = useState({ titulo: pelicula.titulo, descripcion: pelicula.descripcion });

  const enviar = (evento) => {
    evento.preventDefault();
    const titulo = datos.titulo.trim();
    const descripcion = datos.descripcion.trim();
    if (titulo && descripcion) onGuardar({ ...pelicula, titulo, descripcion });
  };

  return (
    <form className="edicion" onSubmit={enviar}>
      <label className="campo">
        <span>Título</span>
        <input
          autoFocus
          value={datos.titulo}
          onChange={(evento) => setDatos({ ...datos, titulo: evento.target.value })}
        />
      </label>
      <label className="campo">
        <span>Descripción</span>
        <textarea
          rows="4"
          value={datos.descripcion}
          onChange={(evento) => setDatos({ ...datos, descripcion: evento.target.value })}
        />
      </label>
      <div className="acciones">
        <button className="boton boton--primario" type="submit">Guardar</button>
        <button className="boton boton--fantasma" type="button" onClick={onCancelar}>Cancelar</button>
      </div>
    </form>
  );
}
